Create a simple web application locally, and zip it.
Login to aws account.
Go to AWS Elastic beanstalk service console page.
Click "create application" and enter the name of your application and click create.
Now, create environment for your application.
Select "Web Server Environment" and click "select"
Next, enter envionemnt information like name, description of your choice.
Select Platform as "Tomcat" and platform branch as "Tomcat 7 with Java 7 running on 64bit Amazon Linux
Now, upload the source code from local file and upload the attached zip file and click "Create environment"
Once the enviornmnet update completed successfully, you will see the Health is ok and in Green color.
you will find the domain name or the URL on the same page: open the URL in the browser and it will display "Hello World"
ex: http://helloworldwebapp-env.eba-eygepjzt.us-east-2.elasticbeanstalk.com/


